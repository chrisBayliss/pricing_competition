from Competitor import Competitor
import numpy as np

class Random_price_competitor(Competitor):

	#store parameterdump here (until competition)

	def __init__(self):
		Competitor.__init__(self)
		np.random.seed(0)
	
	def p(self, prices_historical, demand_historical, parameterdump, t):#
	
		# if it's the first day
		#if demand_historical.size == 0:
		if t == 0:
			#store the number of competitors parameter in parameterdump
			competitor_number=parameterdump[0]
			C=prices_historical.size
			parameterdump=[competitor_number,C]
		
		popt = np.random.uniform(0,100)
		return (popt, parameterdump)