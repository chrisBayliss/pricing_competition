from Competitor import Competitor
import numpy as np
import math as Math

class Sine_competitor(Competitor):

	
	

	def __init__(self):
		Competitor.__init__(self)
		np.random.seed(0)
	
	def p(self, prices_historical, demand_historical, parameterdump, t):#
	
		if t == 0:
			#store the number of competitors parameter in parameterdump
			competitor_number=parameterdump[0]
			C=len(prices_historical)
			#store parameterdump here (until competition)
			#A+B*sin(C*t)
			A=50.0
			B=50.0#0#
			D=0.02
			
			#
			parameterdump=[competitor_number, C, A, B, D]
			
			popt = A+B*Math.sin(D*t)
		else:
			[competitor_number, C, A, B, D]=parameterdump
			popt = A+B*Math.sin(D*t)
			parameterdump=[competitor_number, C, A, B, D]
		
		return (popt, parameterdump)