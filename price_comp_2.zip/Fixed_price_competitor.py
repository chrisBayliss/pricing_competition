from Competitor import Competitor

class Fixed_price_competitor(Competitor):

	def __init__(self):
		Competitor.__init__(self)
	
	def p(self, prices_historical, demand_historical, parameterdump, t):#
	
		# if it's the first day
		#if demand_historical.size == 0:
		if t == 0:
		
			#initialise parameterdump
			competitor_number=parameterdump[0]
			C=prices_historical.size
			fixed_price=50
			parameterdump=[competitor_number, C, fixed_price]
			
		else:
			fixed_price=parameterdump[2]
		
		popt = fixed_price
		return (popt, parameterdump)