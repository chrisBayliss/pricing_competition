# -*- coding: utf-8 -*-	
"""
Created on Mon Mar 06 12:03:52 2017

@author: ae1g15
"""
from Competitor import Competitor
import os, math, operator, random, csv, scipy
import numpy as np

class Epsilon_greedy_competitor(Competitor):	

	def __init__(self):
			Competitor.__init__(self)
		
	def p(self, prices_historical, demand_historical, parameterdump, t):#
	
		####################################
		#declare inner methods of p function
		def ind_max(x):
			m = max(x)
			return x.index(m)

		def select_arm(epsilon,values): #it returns which arm to play
			rand_num=np.random.uniform(0,1)
			#print(rand_num,',',epsilon)  
			if rand_num > epsilon: #it chooses randomly whether it will explore or exploit
				return ind_max(values) #it selects the price with the highest demand so far
			else:
				arm=random.randrange(len(values))
				#print(arm) 
				return arm #it selects a random arm
	   
				
		def update(chosen_arm, reward):
			#print(chosen_arm)
			counts[chosen_arm] = counts[chosen_arm] + 1
			n = counts[chosen_arm]
			value = values[chosen_arm]
			new_value = ((n - 1) / float(n)) * value + (1 / float(n)) * reward #weighted average
			return new_value
		#############################################
	
		index=-1#initialise 'index'
		if t==0: #if it is the first day
			#initialise parameterdump
			#in the format required for the competition 'competitor_number=0'
			competitor_number=parameterdump[0]
			#number of competitors
			C=len(prices_historical)
			#exploration rate
			epsilon=0.1
			#times each price is chosen
			counts = [0 for col in range(10)] # a vector with 10 entries showing how many average reward(demand) obtained by each price
			values = [0.0 for col in range(10)] # a vector with 10 entries showing the 
			#set of prices
			prices=[10, 20, 30, 40, 50, 60, 70, 80, 90, 100] #we test these 10 prices to compare their demand 
			
			
			
			#choose first arm
			index=random.randrange(len(values)) #choose a random price
			index_last_period=index
			
			#add the parameters that you want to store to parameterdump
			parameterdump=[competitor_number, C, epsilon, counts, values, prices, index_last_period]
		else: #if it's not the first day 
			#assign variable names to the contents of our parameter dump
			[competitor_number, C, epsilon, counts, values, prices, index_last_period]=parameterdump
			
			#update for the demand in the previos time period
			#print(demand_historical[t-1],',',self.prices[self.index_last_period])  
			values[index_last_period]=update(index_last_period, demand_historical[t-1]*prices[index_last_period])
			index=select_arm(epsilon, values) #index is the price chosen at t
			index_last_period=index
			
			#add the parameters that you want to store to parameterdump
			parameterdump=[competitor_number, C, epsilon, counts, values, prices, index_last_period]
		
		#after we have chosen price index we receive the demand
		
		
		
		popt = prices[index]
		return (popt, parameterdump)