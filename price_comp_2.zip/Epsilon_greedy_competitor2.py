# -*- coding: utf-8 -*-
"""
Created on Wed May 17 14:47:38 2017

@author: Asus
"""

from Competitor import Competitor
import os, math, operator, random, csv, scipy
import numpy as np


class Epsilon_greedy_competitor2(Competitor):	


	def __init__(self):
			Competitor.__init__(self)
		
	def p(self, prices_historical, demand_historical, parameterdump, t):#
	
		#declare our methods
		###################################################################################
		def update_exp_smooth_params_return_forecast_prices(comp_prices_last_t, t):
		   for c in range(C-1):
			   Base_value[t-1][c]=(alpha*comp_prices_last_t[c])+((1-alpha)*(Base_value[t-2][c]+Trend[t-2][c]))			
			   Trend[t-1][c]=(beta*(Base_value[t-1][c]-Base_value[t-2][c]))+((1-beta)*Trend[t-2][c])			
			   prices_next_t[c]=max(0, min(100,Base_value[t-2][c]+Trend[t-1][c]))
		   return prices_next_t
    
		def ind_max(x):
			#print(x)
			m = max(x)
			return x.index(m)

		def select_arm(epsilon,values): #it returns which arm to play
			rand_num=np.random.uniform(0,1)
			#print(rand_num,',',epsilon)  
			if rand_num > epsilon: #it chooses randomly whether it will explore or exploit
				return ind_max(values) #it selects the price with the highest demand so far
			else:
				arm=random.randrange(len(values))
				#print(arm) 
				return arm #it selects a random arm
	   
				
		def update(row, chosen_arm, reward):
			#print(chosen_arm)
			counts[row, chosen_arm] = counts[row,chosen_arm] + 1
			n = counts[row,chosen_arm]
			value = selection_matrix[row][chosen_arm]#[,]
			new_value = ((n - 1) / float(n)) * value + (1 / float(n)) * reward #weighted average
			return new_value
		
		def sort(FF):
			size=len(FF)
			EE=list(FF)
			BB=[0]*len(FF)
			ind_ord=[0 for i in range(size)]
			for i in range(size):
				BB[i]=i
			DD=[0 for i in range(size)]
			for i in range(size):
				smallest=EE[0]
				position=0
				for j in range(1,size-i):
					if EE[j]<smallest:
						smallest=EE[j]
						position=j
				DD[i]=smallest
				EE.pop(position)
				ind_ord[i]=BB.pop(position)
			return [DD,ind_ord]
		####################################################################################
	
		index=-1#initialise 'index'
		if t==0: #if it is the first day
			#store the number of competitors parameter in parameterdump
			competitor_number=parameterdump[0]
			C=len(prices_historical)
			
			#initialization
			epsilon=0.2 #probability that a random price is chosen
			index_last_period=0
			selection_matrix=[[0.0 for row in range(10)] for col in range(10)]
			counts=np.zeros(shape=(10,10))
			previous_mode_price_index=0
			alpha=0.2
			beta=0.2
			Base_value=[[0 for j in range(C-1)] for i in range(1000)]
			Trend=[[0 for j in range(C-1)] for i in range(1000)]
			prices_next_t=[0 for i in range(C-1)]
			other_prices=[0]*(C-1)
			mode_interval_size=10
			mode_interval_frequencies=[0]*10
			prices=[10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
			
			#initialise parameterdump
			parameterdump=[competitor_number, C, epsilon, index_last_period, selection_matrix, counts, previous_mode_price_index, alpha, beta, Base_value, Trend, prices_next_t, other_prices, mode_interval_size, mode_interval_frequencies, prices]
			
			
			popt=random.randrange(len(prices)) #choose a random price
		
        
		else: #if it's not the first day 
			#assign the variable names to parameterdump
			[competitor_number, C, epsilon, index_last_period, selection_matrix, counts, previous_mode_price_index, alpha, beta, Base_value, Trend, prices_next_t, other_prices, mode_interval_size, mode_interval_frequencies, prices]=parameterdump
			
            #update for the demand in the previos time period
			#print(demand_historical[t-1],',',prices[index_last_period])  
			counter=0
			#print(other_prices)
			for i in range(C):
				if i!=competitor_number:
					other_prices[counter]=prices_historical[i,t-1]
					counter=counter+1		
			[sorted_prices, ind_order]=sort(other_prices)#prices_historical[:,t-1]				            
			forecast_price_set=update_exp_smooth_params_return_forecast_prices(sorted_prices, t)
			if t==1:
			     Base_value[0]=sorted_prices
                       
                       
            #update step
			for i in range(len(mode_interval_frequencies)):
				mode_interval_frequencies[i]=0
				
			for i in range(len(other_prices)):
				interval=int(min(len(mode_interval_frequencies)-1, max(0, math.floor(other_prices[i]/mode_interval_size))))
				mode_interval_frequencies[interval]=mode_interval_frequencies[interval]+1
                                  
			#find the mode price
			max_frequency=0
			mode_price_index=None
			for i in range(len(mode_interval_frequencies)):
				if mode_interval_frequencies[i]>max_frequency:
					max_frequency=mode_interval_frequencies[i]
					mode_price_index=i            
                    
                    
			selection_matrix[mode_price_index][index_last_period]=update(mode_price_index,index_last_period,demand_historical[t-1]*prices[index_last_period])         
        
                       
            #price optimisation
            ################            
            #mode interval frequencies
			#reset
			for i in range(len(mode_interval_frequencies)):
				mode_interval_frequencies[i]=0
				
			for i in range(len(forecast_price_set)):
				interval=int(min(len(mode_interval_frequencies)-1, max(0, math.floor(forecast_price_set[i]/mode_interval_size))))
				mode_interval_frequencies[interval]=mode_interval_frequencies[interval]+1
			
			#find the mode price
			max_frequency=0
			forecast_mode_price_index=None
			for i in range(len(mode_interval_frequencies)):
				if mode_interval_frequencies[i]>max_frequency:
					max_frequency=mode_interval_frequencies[i]
					forecast_mode_price_index=i 
            
			
			index=select_arm(epsilon,selection_matrix[forecast_mode_price_index]) #index is the price chosen at t
			index_last_period=index

			#assign updated variables to parameter dump
			parameterdump=[competitor_number, C, epsilon, index_last_period, selection_matrix, counts, previous_mode_price_index, alpha, beta, Base_value, Trend, prices_next_t, other_prices, mode_interval_size, mode_interval_frequencies, prices]
		
		
			popt = prices[index]
		return (popt, parameterdump)
      
	
