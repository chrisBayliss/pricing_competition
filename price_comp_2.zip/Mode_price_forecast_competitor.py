from Competitor import Competitor
import numpy as np
import math as Math

class Mode_price_forecast_competitor(Competitor):

	

	def __init__(self):
		Competitor.__init__(self)
		np.random.seed(0)
	
	def p(self, prices_historical, demand_historical, parameterdump, t):#, parameterdump
	
		####################################
		#declare inner methods of p function
		def update_exp_smooth_params_return_forecast_prices( comp_prices_last_t, t):
			for c in range(C-1):
				Base_value[t-1][c]=(alpha*comp_prices_last_t[c])+((1-alpha)*(Base_value[t-2][c]+Trend[t-2][c]))
				
				Trend[t-1][c]=(beta*(Base_value[t-1][c]-Base_value[t-2][c]))+((1-beta)*Trend[t-2][c])
				
				prices_next_t[c]=max(0, min(100,Base_value[t-2][c]+Trend[t-1][c]))
			return prices_next_t
			
		def sort( FF):
			size=len(FF)
			EE=list(FF)
			BB=[0]*len(FF)
			ind_ord=[0 for i in range(size)]
			for i in range(size):
				BB[i]=i
			DD=[0 for i in range(size)]
			for i in range(size):
				smallest=EE[0]
				position=0
				for j in range(1,size-i):
					if EE[j]<smallest:
						smallest=EE[j]
						position=j
				DD[i]=smallest
				EE.pop(position)
				ind_ord[i]=BB.pop(position)
			return [DD,ind_ord]
		######################################################
	
		if t == 0:
			#in the format required for the competition 'competitor_number=0'
			competitor_number=parameterdump[0]
			#number of competitors
			C=len(prices_historical)
			alpha=0.2
			beta=0.2
			mode_intervals=[10,20,30,40,50,60,70,80,90,100]
			mode_interval_size=10
			mode_interval_frequencies=[0]*10
			Base_value=[[0 for j in range(C-1)] for i in range(1000)]
			Trend=[[0 for j in range(C-1)] for i in range(1000)]
			prices_next_t=[0 for i in range(C-1)]
			other_prices=[0]*(C-1)
			
			#add the parameters that you want to store to parameterdump
			parameterdump=[competitor_number, C, alpha, beta, mode_intervals, mode_interval_size, mode_interval_frequencies, Base_value, Trend, prices_next_t, other_prices]
			
			
			popt = np.random.uniform(0,100)
		elif t<2:
			#unpack parameterdump
			[competitor_number, C, alpha, beta, mode_intervals, mode_interval_size, mode_interval_frequencies, Base_value, Trend, prices_next_t, other_prices]=parameterdump
			
			#initialise base value (trend initialised to 0)
			#for c in range(C):
			counter=0
			for i in range(C):
				if i!=competitor_number:
					other_prices[counter]=prices_historical[i,t-1]
					counter=counter+1
			
			[sorted_prices, ind_order]=sort(other_prices)#prices_historical[:,t-1]
			Base_value[0]=sorted_prices
			
			parameterdump=[competitor_number, C, alpha, beta, mode_intervals, mode_interval_size, mode_interval_frequencies, Base_value, Trend, prices_next_t, other_prices]
			
			#random initial price
			popt = np.random.uniform(0,100)
		else:
			#unpack parameterdump
			[competitor_number, C, alpha, beta, mode_intervals, mode_interval_size, mode_interval_frequencies, Base_value, Trend, prices_next_t, other_prices]=parameterdump
			
			
			#prices offered in the previous time period
			counter=0
			for i in range(C):
				if i!=competitor_number:
					other_prices[counter]=prices_historical[i,t-1]
					counter=counter+1
			
			[sorted_prices, ind_order]=sort(other_prices)#prices_historical[:,t-1]
			
			
			forecast_price_set=update_exp_smooth_params_return_forecast_prices(sorted_prices, t)
			
			#mode interval frequencies
			#reset
			for i in range(len(mode_interval_frequencies)):
				mode_interval_frequencies[i]=0
				
			for i in range(len(forecast_price_set)):
				interval=min(len(mode_interval_frequencies)-1, max(0, Math.floor(forecast_price_set[i]/mode_interval_size)))
				mode_interval_frequencies[int(interval)]=mode_interval_frequencies[int(interval)]+1
			
			#find the mode price
			max_frequency=0
			mode_price_index=None
			for i in range(len(mode_interval_frequencies)):
				if mode_interval_frequencies[i]>max_frequency:
					max_frequency=mode_interval_frequencies[i]
					mode_price_index=i
					
			parameterdump=[competitor_number, C, alpha, beta, mode_intervals, mode_interval_size, mode_interval_frequencies, Base_value, Trend, prices_next_t, other_prices]
			
			popt = mode_intervals[mode_price_index]
		
		return (popt, parameterdump)